#' Sample data means
#'
#' @description The average proportion of customers that stayed on the website
#' for longer than 5 minutes each month.
#'
#' @format A vector of length 12
#'
#'
"months.means"

